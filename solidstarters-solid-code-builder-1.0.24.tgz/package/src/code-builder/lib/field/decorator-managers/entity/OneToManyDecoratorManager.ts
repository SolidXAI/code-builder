import { camelize, classify } from "@angular-devkit/core/src/utils/strings";
import ts, { ModifierLike, ObjectLiteralElementLike, PropertyDeclaration } from "@schematics/angular/third_party/github.com/Microsoft/TypeScript/lib/typescript";
import { insertImport } from "@schematics/angular/utility/ast-utils";
import { Change } from "@schematics/angular/utility/change";
import { DecoratorManager, PartialAddFieldChange } from "../../FieldManager";

interface OneToManyDecoratorOptions {
    isOneToMany: boolean;
    relationModelName: string;
    relationInverseFieldName: string;
    source: ts.SourceFile;
    field: any;
    fieldName: string;
    modelName: string;
}

export class OneToManyDecoratorManager implements DecoratorManager {
    constructor(public options: OneToManyDecoratorOptions, public fieldNode?: PropertyDeclaration,) { }
    isApplyDecorator(): boolean {
        return this.options.isOneToMany;
    }
    decoratorName(): string {
        return 'OneToMany';
    }

    buildDecorator(): PartialAddFieldChange {
        const changes: Change[] = [];
        const fieldSourceLines: string[] = [];

        // Add the one-to-many import
        // const oneToManyImport = insertImport(
        //     this.options.source,    
        //     this.options.source.fileName,
        //     this.decoratorName(),
        //     'typeorm',
        // );
        // if (oneToManyImport) {
        //     changes.push(oneToManyImport);
        // }
        // fieldSourceLines.push(
        //     `@${this.decoratorName()}(() => ${classify(this.options.modelName)}, ${camelize(this.options.modelName)} => ${camelize(this.options.modelName)}.${this.options.fieldName}, ${this.buildRelationOptionsCode()})`,
        // );
        changes.push(...this.decoratorImports());

        const fieldSourceLineComponents: string[] = [];
        fieldSourceLineComponents.push(`() => ${classify(this.options.relationModelName)}`);
        this.options.relationInverseFieldName ? fieldSourceLineComponents.push(`${camelize(this.options.relationModelName)} => ${camelize(this.options.relationModelName)}.${this.options.relationInverseFieldName}`) : "no-ops";
        fieldSourceLineComponents.push(`${this.buildRelationOptionsCode()}`);
        fieldSourceLines.push(`@${this.decoratorName()}(${fieldSourceLineComponents.join(', ')})`);

        return {
            filePath: this.options.source.fileName,
            field: this.options.field,
            changes: changes,
            fieldSourceLines: fieldSourceLines,
        };
    }

    setFieldNode(fieldNode: PropertyDeclaration): void {
        this.fieldNode = fieldNode;
    }

    decoratorImports(): Change[] {
        return [insertImport(
            this.options.source,
            this.options.source.fileName,
            this.decoratorName(),
            'typeorm')]
    }

    updateDecorator(): [PropertyDeclaration, Change[]] {
        // Check if the field property declaration exists, if not throw an error
        if (!this.fieldNode) throw new Error('Field node is required for updating the one to many decorator');

        let newModifiers: ModifierLike[] = [];
        let existingModifiers = this.fieldNode.modifiers;

        // Check if field has an existing one-to-many relation decorator
        const existingDecorator = this.findDecorator(this.decoratorName(), existingModifiers);

        //Remove the many-to-one decorator if it exists
        //TODO probably this too can be done in a lesser intrusive way i.e update everything instead of removing and adding
        newModifiers = [...this.filterNonDecorators(existingModifiers), ...this.filterOtherDecorators(this.decoratorName(), existingModifiers)];

        //Add the one-to-many decorator if it is required  
        const changes: Change[] = [];  

        if (this.isApplyDecorator()) {
            newModifiers = [...newModifiers, this.createRelationDecorator(existingDecorator)];
            changes.push(...this.decoratorImports());
        }

        const updatedProperty = ts.factory.updatePropertyDeclaration(
            this.fieldNode,
            newModifiers, //Replace with new modifiers
            this.fieldNode.name,
            this.fieldNode.questionToken,
            this.fieldNode.type,
            this.fieldNode.initializer,
        );
        return [updatedProperty, changes];
    }

    private buildRelationOptionsCode(): string {
        return `{ cascade: true }`;
    }

    private createRelationDecorator(existingRelationDecorator: ts.Decorator | undefined): ts.Decorator {
        // Capture the existing relation decorator options
        let existingRelationDecoratorPropertyAssignments: ts.ObjectLiteralElementLike[] = this.existingDecoratorOptions(existingRelationDecorator);

        // Create the new relation decorator options
        const decoratorOptions = this.createRelationDecoratorOptions();
        const newPropertyAssignments: ObjectLiteralElementLike[] = Array.from(decoratorOptions.values()).filter(p => p !== null) as ts.PropertyAssignment[];

        // console.log('newPropertyAssignments', newPropertyAssignments.map(p => JSON.stringify(p.name)).join(', '));

        // Add the other unhandled column decorator options
        const handledDecoratorOptions = Array.from(decoratorOptions.keys());
        //@ts-ignore
        const otherPropertyAssignments = existingRelationDecoratorPropertyAssignments.filter(ps => !handledDecoratorOptions.includes(ps.name?.escapedText as string));
        newPropertyAssignments.push(...otherPropertyAssignments);

        // Re-create the relation decorator with the merged relation decorator options
        const decoratorIdentifier = ts.factory.createIdentifier(this.decoratorName());
        const argumentsArray: ts.Expression[] = this.createDecoratorArguments(newPropertyAssignments);
        const call = ts.factory.createCallExpression(decoratorIdentifier, undefined, argumentsArray);
        return ts.factory.createDecorator(call)
    }

    private createDecoratorArguments(newPropertyAssignments: ts.ObjectLiteralElementLike[]) {
        const argumentsArray: ts.Expression[] = [];
        // 1st Argument: Target
        const typeFunctionOrTarget = ts.factory.createArrowFunction(
            undefined,
            undefined,
            [],
            undefined,
            ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
            ts.factory.createIdentifier(classify(this.options.relationModelName))
        );
        argumentsArray.push(typeFunctionOrTarget);
        // 2nd Argument: Inverse side
        const inverseSide = ts.factory.createArrowFunction(
            undefined,
            undefined,
            [ts.factory.createParameterDeclaration(
                undefined,
                undefined,
                ts.factory.createIdentifier(camelize(this.options.relationModelName)),
                undefined,
                undefined,
                undefined
            )],
            undefined,
            ts.factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
            ts.factory.createPropertyAccessExpression(
                ts.factory.createIdentifier(camelize(this.options.relationModelName)),
                ts.factory.createIdentifier(this.options.relationInverseFieldName)
            )
        );
        argumentsArray.push(inverseSide);
        // 3rd Argument: Options. This argument is optional
        if (newPropertyAssignments.length > 0) {
            const decoratorOptions = ts.factory.createObjectLiteralExpression(newPropertyAssignments);
            argumentsArray.push(decoratorOptions);
        }
        return argumentsArray;
    }

    private existingDecoratorOptions(existingRelationDecorator: ts.Decorator | undefined): ts.ObjectLiteralElementLike[] {
        let existingRelationDecoratorPropertyAssignments: ts.ObjectLiteralElementLike[] = [];
        if (existingRelationDecorator !== undefined) {
            //Pre-set the relation options from the existing relation decorator
            const existingCallExpression = existingRelationDecorator.expression as ts.CallExpression;
            // Check if  call expression has at least 1 arguments
            if (existingCallExpression.arguments.length > 2) { //Because we are interested in the 2nd argument, we check for length > 1
                if (!ts.isObjectLiteralExpression(existingCallExpression.arguments[2])) { throw new Error('OneToMany decorator 3rd argument must be an object literal containing the relation options'); }
                const existingObjectLiteralExpression = existingCallExpression.arguments[2] as ts.ObjectLiteralExpression;
                existingRelationDecoratorPropertyAssignments.push(...existingObjectLiteralExpression.properties);
            }
        }
        return existingRelationDecoratorPropertyAssignments;
    }

    private createRelationDecoratorOptions(): Map<string, ts.PropertyAssignment | null> {
        const options: any = new Map<string, ts.Expression>();
        options.set('cascade', ts.factory.createTrue());
        return this.optionsToPropertyAssignmentsOrNull(options);
    }

    private optionsToPropertyAssignmentsOrNull(options: Map<string, ts.Expression | null>): Map<string, ts.PropertyAssignment | null> {
        const decoratorOptions = new Map<string, ts.PropertyAssignment | null>();
        options.forEach((value, key) => {
            if (value !== null) {
                decoratorOptions.set(key, ts.factory.createPropertyAssignment(ts.factory.createIdentifier(key), value));
            }
            else {
                decoratorOptions.set(key, null);
            }
        });
        return decoratorOptions;
    }


    private findDecorator(name: string, existingModifiers: ts.NodeArray<ts.ModifierLike> | undefined): ts.Decorator | undefined {
        return existingModifiers ? existingModifiers.filter((m) => (m.kind === ts.SyntaxKind.Decorator)).map(m => m as ts.Decorator).filter(m => this.containsIdentifierName(m, name)).pop() : undefined;
    }

    private filterOtherDecorators(name: string, existingModifiers: ts.NodeArray<ts.ModifierLike> | undefined): ts.Decorator[] {
        return existingModifiers ? existingModifiers.filter((m) => (m.kind === ts.SyntaxKind.Decorator)).map(m => m as ts.Decorator).filter(m => !this.containsIdentifierName(m, name)) : [];
    }

    private filterNonDecorators(existingModifiers: ts.NodeArray<ts.ModifierLike> | undefined): ts.Modifier[] {
        return existingModifiers ? existingModifiers.filter((m) => (m.kind !== ts.SyntaxKind.Decorator)).map(m => m as ts.Modifier) : [];
    }

    private containsIdentifierName(m: ts.Decorator, identifierName: string): boolean {
        const callExpression = m.expression as ts.CallExpression;
        const identifier = callExpression.expression as ts.Identifier;
        return identifier.text === identifierName;
    }

}